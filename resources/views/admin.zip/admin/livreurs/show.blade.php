@extends('layouts.admin')

@section('title', 'Détails du livreur')

@section('actions')
    <a href="{{ route('admin.livreurs.index') }}" class="btn btn-sm btn-secondary">
        <i class="fas fa-arrow-left me-1"></i> Retour
    </a>
@endsection

@section('content')
<div class="row">
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Informations personnelles</h5>
            </div>
            <div class="card-body">
                <div class="text-center mb-4">
                    <img src="{{ asset('storage/default_photo.jpg') }}" alt="Photo de John Doe" class="img-fluid rounded-circle" style="width: 150px; height: 150px; object-fit: cover;">
                </div>
                
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between">
                        <span class="fw-bold">Nom:</span> 
                        <span>ndeya cisse</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span class="fw-bold">Email:</span> 
                        <span>ndeya.cisse@gmail.com</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span class="fw-bold">Téléphone:</span> 
                        <span>+221 78 123 45 67</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span class="fw-bold">Adresse:</span> 
                        <span>123 Rue Principal, Dakar, Sénégal</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span class="fw-bold">CNI:</span> 
                        <span>123456789012345</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between">
                        <span class="fw-bold">Inscrit le:</span> 
                        <span>01/01/2022</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">Informations professionnelles</h5>
            </div>
            <div class="card-body">
                <ul class="list-group list-group-flush mb-4">
                    <li class="list-group-item d-flex justify-content-between">
                        <span class="fw-bold">Type de véhicule:</span> 
                        <span>Vélo</span>
                    </li>
                    <!-- Ajoutez plus d'informations professionnelles si nécessaire -->
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection
