@extends('layouts.admin')

@section('title', 'Livreurs en attente de validation')

@section('content')
<div class="card">
    <div class="card-body">
        <!-- Simulation de données statiques -->
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Email</th>
                        <th>Téléphone</th>
                        <th>Type de véhicule</th>
                        <th>Date d'inscription</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>ndeya cisse</td>
                        <td>ndeya.cisse@gmail.com</td>
                        <td>123456789</td>
                        <td>Vélo</td>
                        <td>01/01/2023 10:00</td>
                        <td>
                            <a href="#" class="btn btn-sm btn-info">
                                <i class="fas fa-eye"></i> Détails
                            </a>
                            <button class="btn btn-sm btn-success">
                                <i class="fas fa-check"></i> Valider
                            </button>
                            <button class="btn btn-sm btn-danger">
                                <i class="fas fa-times"></i> Refuser
                            </button>
                        </td>
                    </tr>
                    <!-- Ajoutez plus de lignes pour tester -->
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            <!-- Pagination statique -->
            <ul class="pagination">
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
            </ul>
        </div>
    </div>
</div>
@endsection
