@extends('layouts.admin')

@section('title', 'Configuration des Tarifs')

@section('content')
<div class="card">
    <div class="card-header">
        <h5 class="card-title">Liste des Tarifs</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Type de Service</th>
                        <th>Distance (km)</th>
                        <th>Poids (kg)</th>
                        <th>Prix (FCFA)</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Standard</td>
                        <td>0-10 km</td>
                        <td>0-5 kg</td>
                        <td>1000 FCFA</td>
                        <td>
                            <a href="#" class="btn btn-sm btn-info">
                                <i class="fas fa-edit"></i> Modifier
                            </a>
                            <button class="btn btn-sm btn-danger">
                                <i class="fas fa-trash"></i> Supprimer
                            </button>
                        </td>
                    </tr>
                    <tr>
                        <td>Express</td>
                        <td>0-10 km</td>
                        <td>0-5 kg</td>
                        <td>1500 FCFA</td>
                        <td>
                            <a href="#" class="btn btn-sm btn-info">
                                <i class="fas fa-edit"></i> Modifier
                            </a>
                            <button class="btn btn-sm btn-danger">
                                <i class="fas fa-trash"></i> Supprimer
                            </button>
                        </td>
                    </tr>
                    <!-- Ajoutez plus de lignes pour tester -->
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            <!-- Pagination statique -->
            <ul class="pagination">
                <li class="page-item"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
            </ul>
        </div>
    </div>
</div>
@endsection
