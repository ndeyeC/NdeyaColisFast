@extends('layouts.admin')

@section('title', 'Communications')

@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="card-title">Communications</h5>
            </div>
            <div class="card-body">
                <div class="chat-container">
                    <div class="chat-box">
                        <div class="message">
                            <span class="user-name">Utilisateur :</span> Bonjour, comment puis-je vous aider aujourd'hui ?
                        </div>
                        <div class="message reply bg-light">
                            <span class="user-name">Réponse :</span> Je voudrais savoir l'état de ma commande.
                        </div>
                        <!-- Plus de messages -->
                    </div>
                    <div class="chat-input mt-4">
                        <input type="text" class="form-control" placeholder="Écrire un message...">
                        <button class="btn btn-primary mt-2">Envoyer</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="card-title">Notifications</h5>
            </div>
            <div class="card-body">
                <div class="alert alert-info">
                    Nouveau message de [Nom Utilisateur] : "Votre commande est en cours de livraison."
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
